=== Srizon Responsive Youtube Album Pro ===
Contributors: afzal_du
Donate link: http://www.srizon.com/srizon-responsive-youtube-album
Tags: Youtube, Album, Gallery, Video Album, Video Gallery, Youtube Album, Youtube Gallery
Requires at least: 3.3
Tested up to: 4.1.2
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This wordpress plugin fetches your or someone else's video (uploads or favorites) from youtube channels and creates beautiful albums using the retrieved info. Video is played on a responsive lightbox . You can add as many albums as you want. It will generate the shortcodes automatically which you can copy/paste into your post or page

== Description ==

This wordpress plugin fetches your or someone else's video (uploads or favorites) from youtube channels and creates beautiful albums using the retrieved info. Video is played on a responsive lightbox . You can add as many albums as you want. It will generate the shortcodes automatically which you can copy/paste into your post or page
= Demo =
* http://wp.srizon.com/srizon-responsive-youtube-album-demo/

= Free Version's Limitation =
* syncs 25 videos per channel
* playlist is not supported (only channel uploads, subscribed videos and favorites)
* 2 layouts available


= Pro Version =
* you can sync as many videos as you want (assuming that your connection and server's memory can handle the data)
* playlist is also supported besides channel uploads and favorites
* 3 layouts available (one additional responsive slider besides 2 free layouts) and more will be added soon



== Installation ==

1. Upload srizon-youtube-album-pro folder to the `/wp-content/plugins/` directory (remove free version first)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the admin Menu 'Youtube Album' and follow instructions there


== Frequently asked questions ==

== Screenshots ==
1. Thumb with description layout - wide view
2. Thumb Grid layout - wide view
3. Video in responsive lightbox - wide view
4. Video in responsive lightbox - small screen
5. Thumb Grid layout - small screen
6. Admin View - Adding album - basic
7. Admin View - Adding album - layout related options
8. Admin View - Album list with shortcodes

== Changelog ==

= 1.0.0 =
* First Release
= 1.1.0 =
* Added support for user's subscribed videos
= 1.1.1 =
* Lightbox Script Update
= 1.2 =
* Auto update notification script added
* Pagination style changed
* Made compatible with latest 'Srizon Facebook Album'
= 1.3 =
* New API (V3) implemented
* Lightbox script updated for loading a bigger video player on large screens
* New overlay button
